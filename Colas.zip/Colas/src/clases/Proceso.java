/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clases;

import java.util.LinkedList;
import java.util.Queue;

public class Proceso {
    private Queue<Orden> orden;

    public Proceso() {
        orden = new LinkedList<>();
    }

    public void añadirOrden(Orden compra) {
        orden.add(compra);
        System.out.println("Orden recibida de " + compra.getNombre() + ": " + compra.getCantidad() + " productos.");
    }

    public Orden cargando() {
        if (!orden.isEmpty()) {
            Orden compra = orden.poll();
            System.out.println("Procesando orden de " + compra.getNombre() + ": " + compra.getCantidad() + " productos.");
            return compra;
        }
        return null;
    }

    public int pendientes() {
        return orden.size();
    }

}