/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clases;

public class Main {
    public static void main(String[] args) {
        Proceso proceso = new Proceso();

        proceso.añadirOrden(new Orden("Cliente 1", 5));
        proceso.añadirOrden(new Orden("Cliente 2", 3));
        proceso.añadirOrden(new Orden("Cliente 3", 8));

        System.out.println("Ordenes pendientes de procesar: " + proceso.pendientes());

        while (proceso.pendientes() > 0) {
            Orden cargando = proceso.cargando();
            System.out.println("Ordenes pendientes de procesar: " + proceso.pendientes());
        }
    }
}